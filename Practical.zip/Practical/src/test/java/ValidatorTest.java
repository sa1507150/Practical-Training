import junit.framework.TestCase;
import java.io.IOException;
import java.util.List;

public class ValidatorTest extends TestCase {
    String excelFilePath = "/Users/Shaikha/Desktop/Records.xlsx";
    Validator validator = new Validator();
    List<Record> records;

    {
        try {
            records = Reader.read(excelFilePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void testValidateDate() {
        assertTrue(validator.validateDate(records.get(0).getArrivalDate()));
    }
    public void testValidateVisaNo() {
        assertTrue(validator.validateVisa(records.get(0).getVisaNo()));
    }
    public void testValidatePassport() {
        assertTrue(validator.validatePassport(records.get(0).getPassport()));
    }
    public void testValidateNotEmpty() {
        assertTrue(validator.validateNotEmpty(records.get(0)));
    }
    public void testValidateRecord() {
        assertTrue(validator.validateRecord(records.get(0)));
    }
}