import org.junit.Test;
import java.io.IOException;
import java.util.List;

import static org.junit.Assert.*;

public class ReaderTest {

    @Test
    public void read() throws IOException {
        String excelFilePath = "/Users/Shaikha/Desktop/Records.xlsx";
        List<Record> records = Reader.read(excelFilePath);

        assertEquals(11, records.size());
        assertNotEquals(15, records.size());
    }

}