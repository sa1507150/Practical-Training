public class Record {
    private int serialNo;
    private String workerName;
    private String passport;
    private String visaNo;
    private String sponsorName;
    private String arrivalDate;
    private String remark;

    public Record(int serialNo, String workerName, String passport, String visaNo, String sponsorName, String arrivalDate, String remark) {
        this.serialNo = serialNo;
        this.workerName = workerName;
        this.passport = passport;
        this.visaNo = visaNo;
        this.sponsorName = sponsorName;
        this.arrivalDate = arrivalDate;
        this.remark = remark;
    }

    public Record() {
    }

    public int getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(int serialNo) {
        this.serialNo = serialNo;
    }

    public String getWorkerName() {
        return workerName;
    }

    public void setWorkerName(String workerName) {
        this.workerName = workerName;
    }

    public String getPassport() {
        return passport;
    }

    public void setPassport(String passport) {
        this.passport = passport;
    }

    public String getVisaNo() {
        return visaNo;
    }

    public void setVisaNo(String visaNo) {
        this.visaNo = visaNo;
    }

    public String getSponsorName() {
        return sponsorName;
    }

    public void setSponsorName(String sponsorName) {
        this.sponsorName = sponsorName;
    }

    public String getArrivalDate() {
        return arrivalDate;
    }

    public void setArrivalDate(String arrivalDate) {
        this.arrivalDate = arrivalDate;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    @Override
    public String toString() {
        return "Record{" +
                "serialNo=" + serialNo +
                ", workerName='" + workerName + '\'' +
                ", passport='" + passport + '\'' +
                ", visaNo='" + visaNo + '\'' +
                ", sponsorName='" + sponsorName + '\'' +
                ", arrivalDate='" + arrivalDate + '\'' +
                ", remark='" + remark + '\'' +
                '}' + '\n';
    }
}
