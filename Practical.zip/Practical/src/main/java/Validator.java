import org.apache.commons.lang.StringUtils;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validator {

    public boolean validateDate(String arrivalDate){
        if (!arrivalDate.trim().equals("")) {
            SimpleDateFormat sdfrmt = new SimpleDateFormat("d-MMM-yy");
            sdfrmt.setLenient(false);
            try {
                Date javaDate = sdfrmt.parse(arrivalDate);
                return true;
            } catch (ParseException e) {
                return false;
            }
        }
        return true;
    }
    public boolean validateVisa(String visaNo) {
        if(StringUtils.isNumeric(visaNo)){
            int length = String.valueOf(visaNo).length();
            return length == 12;
        }else{
            return false;
        }
    }
    public boolean validateNotEmpty(Record record){
        return record != null;
    }
    public boolean validatePassport(String passport) {
        String regex = "\\s*[a-zA-Z]{2}\\d{7}\\s*";
        Pattern p = Pattern.compile(regex);
        if (passport == null) {
            return false;
        }
        Matcher m = p.matcher(passport);
        return m.matches();
    }
    public boolean validateName(String name) {
        String regex = "[a-zA-Z]+";
        Pattern p = Pattern.compile(regex);
        if (name == null) {
            return false;
        }
        Matcher m = p.matcher(name);
        return m.matches();
    }

    public boolean validateRecord(Record record){
        boolean recordIsValid=false;
        if(validateNotEmpty(record)){
            if(record.getWorkerName() != null){
                recordIsValid = validateName(record.getWorkerName());
            }
            if (record.getSponsorName() != null){
                recordIsValid = validateName(record.getSponsorName());
            }
            if (record.getPassport() != null){
                recordIsValid = validatePassport(record.getPassport());
            }
            if (record.getArrivalDate() != null){
                recordIsValid = validateDate(record.getArrivalDate());
            }
            if(record.getVisaNo() != null){
                recordIsValid = validateVisa(record.getVisaNo());
            }
        }
        return recordIsValid;
    }
}
