import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Reader {

    static List<Record> recordList = new ArrayList<>();

    public static List<Record> read(String excelFilePath) throws IOException {
        FileInputStream inputStream = new FileInputStream(excelFilePath);

        Workbook workbook = new XSSFWorkbook(inputStream);
        Sheet firstSheet = workbook.getSheetAt(0);

        for (Row nextRow : firstSheet) {
            Iterator<Cell> cellIterator = nextRow.cellIterator();
            Record record = new Record();
            while (cellIterator.hasNext()) {
                Cell nextCell = cellIterator.next();
                int columnIndex = nextCell.getColumnIndex();

                switch (columnIndex) {
                    case 0:
                        record.setSerialNo(Integer.parseInt(new DataFormatter().formatCellValue(nextCell)));
                        break;
                    case 1:
                        record.setWorkerName(new DataFormatter().formatCellValue(nextCell));
                        break;
                    case 2:
                        record.setPassport(new DataFormatter().formatCellValue(nextCell));
                        break;
                    case 3:
                        record.setVisaNo(new DataFormatter().formatCellValue(nextCell));
                        break;
                    case 4:
                        record.setSponsorName(new DataFormatter().formatCellValue(nextCell));
                        break;
                    case 5:
                        record.setArrivalDate(new DataFormatter().formatCellValue(nextCell));
                        break;
                    case 6:
                        record.setRemark(new DataFormatter().formatCellValue(nextCell));
                        break;
                }


            }
            recordList.add(record);
        }

        workbook.close();
        inputStream.close();

        return recordList;
    }

}
